[INSTRUCTIONS]

- Copy the four files in the same directory as the game's executable.
- Download "dinput8.dll" (Win32) from the Ultimate ASI Loader GitHub and copy it in the same directory as the game's executable.
- Open the .ini file corresponding to what you want to unlock, make the changes, and save.

- ENJOY! 